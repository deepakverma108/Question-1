# AI-Powered Resume Screening & Candidate Ranking System

Automates the first pass of resume screening: upload a batch of resumes
against a job description, and get back candidates ranked by fit, with
matched/missing skills, exportable to CSV or Excel.

Built for the **AI Engineer** assignment — Question 1 (Resume Screening &
Candidate Ranking System).

## How it works

1. **Parsing** (`app/resume_parser.py`) — pulls text out of PDF (via
   `pdfplumber`) and DOCX (via `python-docx`), then uses regex + a skill
   keyword list to extract name, email, phone, skills, education,
   experience (years + date ranges) and certifications. Rule-based on
   purpose: resumes are inconsistent enough that a transparent extractor is
   much easier to debug and extend than a black box.
2. **Matching** (`app/matcher.py`) — the match score (0–100) blends two
   signals:
   - **Skill overlap** (60% weight by default) — how many of the job's
     required/preferred skills appear in the resume, with required skills
     counted double.
   - **Text similarity** (40% weight) — TF-IDF + cosine similarity between
     the full resume text and job description, to catch relevant
     experience the fixed skill list misses.
   Weights are configurable via `SKILL_WEIGHT` / `TEXT_SIMILARITY_WEIGHT`
   env vars.
3. **API** (`app/routes/`) — FastAPI endpoints to create jobs, upload
   resumes, list/filter/rank candidates, export, shortlist, notify, and
   generate interview questions.
4. **Dashboard** (`static/index.html`) — a plain HTML/JS page (no build
   step) that hits the API: create a job, upload resumes, see rankings,
   filter, shortlist, export.

## Quick start

### Option A — Docker (recommended, includes Postgres)

```bash
docker compose up --build
```

- API: http://localhost:8000
- Swagger docs: http://localhost:8000/docs
- Dashboard: http://localhost:8000/dashboard

### Option B — Local (SQLite, no Docker/Postgres needed)

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # edit if you want Postgres instead of SQLite
uvicorn app.main:app --reload
```

## Running tests

```bash
pip install -r requirements.txt
pytest -v
```

19 tests covering the parser, the scoring engine, and the API end-to-end
(job creation, upload, ranking, filtering, export, shortlisting).

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/jobs` | Create a job description |
| GET | `/api/v1/jobs` | List jobs |
| GET | `/api/v1/jobs/{id}` | Get one job |
| POST | `/api/v1/resumes/upload` | Upload one or more resumes (multipart) for a job |
| GET | `/api/v1/candidates?job_id=` | Ranked candidates, with `min_score`, `min_experience`, `skill`, `education_contains` filters |
| GET | `/api/v1/candidates/{id}` | Full candidate detail, incl. raw extracted text |
| GET | `/api/v1/candidates/export/{job_id}?file_format=csv\|xlsx` | Export ranked shortlist |
| POST | `/api/v1/candidates/shortlist` | Mark candidates shortlisted |
| POST | `/api/v1/candidates/notify` | Email shortlisted candidates (needs SMTP config) |
| GET | `/api/v1/candidates/{id}/interview-questions` | Auto-generated interview questions from the resume |

Full interactive docs (Swagger/OpenAPI) at `/docs` once the server is running.

## Project layout

```
app/
  main.py              FastAPI app, router registration, static mount
  config.py            Settings (env-driven)
  database.py           SQLAlchemy engine/session
  models.py            Job, Candidate ORM models
  schemas.py            Pydantic request/response models
  resume_parser.py      PDF/DOCX -> structured fields
  matcher.py             Scoring engine (skills + TF-IDF)
  routes/
    jobs.py
    resumes.py
    candidates.py
  utils/
    logger.py
    exceptions.py        Custom exceptions + FastAPI error handlers
static/
  index.html             Dashboard (vanilla JS, no build step)
tests/
  test_parser.py
  test_matcher.py
  test_api.py
sample_data/
  job_description_sample.txt
  resumes/               3 sample resumes (2 .docx, 1 .pdf)
Dockerfile
docker-compose.yml       api + Postgres
requirements.txt
.env.example
```

## Design notes / trade-offs

- **Database schema**: two tables — `jobs` and `candidates` (candidate rows
  reference a job and store both raw extracted fields and match results).
  Works unchanged against SQLite (default, zero-setup), PostgreSQL, or
  MySQL — just point `DATABASE_URL` at whichever one you want. `docker-compose.yml`
  wires up Postgres by default per the assignment's technical requirements.
- **Why TF-IDF instead of embeddings by default**: it needs no external API
  key or model download, runs in milliseconds, and is fully explainable
  (you can literally show which terms drove the similarity score) — a
  reasonable default for a self-contained take-home project. `app/matcher.py`
  has an `embedding_similarity()` stub already wired into the scoring
  pipeline for swapping in a real embeddings provider (the "semantic search"
  bonus feature).
- **Logging & error handling**: all errors funnel through custom exceptions
  (`JobNotFoundError`, `UnsupportedFileTypeError`, `ResumeParseError`, etc.)
  registered as FastAPI exception handlers, so the API returns consistent
  JSON error bodies instead of raw tracebacks, and every request outcome is
  logged.

## Bonus features implemented

- ✅ **AI-generated interview questions** — template-based, per matched
  skill (to probe depth) and missing skill (to probe learning ability),
  from the candidate's own resume. Swap in an LLM call in
  `generate_interview_questions()` for more open-ended phrasing.
- ✅ **Email notification to shortlisted candidates** — `POST
  /candidates/notify`, gated behind SMTP env vars so it's opt-in.
- ⚙️ **Semantic search via embeddings** — hook is in place
  (`matcher.embedding_similarity`), not enabled by default (see trade-offs
  above).
- ⚙️ **OCR for scanned resumes** — not implemented in this pass; the
  cleanest addition point is `resume_parser.extract_text()`, falling back to
  `pytesseract` on a page-rendered image when `pdfplumber` returns no text
  for a page.

## Sample data

`sample_data/job_description_sample.txt` plus three sample resumes
(`sample_data/resumes/`) at different fit levels, so you can try the whole
flow immediately: a strong senior match, a solid mid-level match, and a
weak junior match, to see the ranking spread work as intended.
