"""
Central configuration for the app. Everything is pulled from environment
variables (see .env.example) so the same image can run against Postgres in
prod and SQLite for local/dev/testing without code changes.
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "AI Resume Screening & Candidate Ranking System"
    api_prefix: str = "/api/v1"

    # Falls back to a local SQLite file if DATABASE_URL isn't set, so the
    # project runs out of the box without needing Postgres installed.
    database_url: str = "sqlite:///./resume_screening.db"

    # Where uploaded resumes get stored before/after parsing.
    upload_dir: str = "./uploads"

    # Match score weighting: how much of the final score comes from
    # skill-overlap vs. overall semantic/TF-IDF similarity of the full text.
    skill_weight: float = 0.6
    text_similarity_weight: float = 0.4

    # SMTP settings for the (optional) shortlist notification feature.
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = "noreply@example.com"

    log_level: str = "INFO"

    class Config:
        env_file = ".env"


settings = Settings()
