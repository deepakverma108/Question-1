from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import Base, engine
from app.routes import jobs, resumes, candidates
from app.utils.exceptions import register_exception_handlers
from app.utils.logger import logger

# In a real deployment this would be handled by Alembic migrations; kept as
# a simple create_all() here since the assignment scope doesn't call for a
# migration framework, and this still works fine against Postgres/MySQL.
Base.metadata.create_all(bind=engine)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"{settings.app_name} starting up")
    yield


app = FastAPI(
    title=settings.app_name,
    description=(
        "Automates resume screening: upload resumes for a job, extract "
        "structured candidate info, rank candidates by fit, and export a "
        "shortlist."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

register_exception_handlers(app)

app.include_router(jobs.router, prefix=settings.api_prefix)
app.include_router(resumes.router, prefix=settings.api_prefix)
app.include_router(candidates.router, prefix=settings.api_prefix)

static_dir = Path(__file__).resolve().parent.parent / "static"
if static_dir.exists():
    app.mount("/dashboard", StaticFiles(directory=str(static_dir), html=True), name="dashboard")


@app.get("/", tags=["Health"])
def root():
    return {
        "status": "ok",
        "service": settings.app_name,
        "docs": "/docs",
        "dashboard": "/dashboard",
    }


@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy"}
