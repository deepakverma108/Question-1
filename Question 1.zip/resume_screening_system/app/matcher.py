"""
Scores a parsed resume against a job description.

The final match score (0-100) blends two signals:
  1. Skill overlap - how many of the job's required/preferred skills show
     up in the resume (this is the part recruiters care most about and is
     the easiest to explain/justify to a candidate).
  2. Overall text similarity - TF-IDF + cosine similarity between the full
     resume text and the job description, which catches relevant
     experience that isn't captured by the fixed skill keyword list.

Swapping step 2 for an embeddings-based (LLM) similarity score is a drop-in
change - see `embedding_similarity()` below, which is stubbed out so the
weighting logic doesn't need to change when that's wired up to a real
embeddings provider.
"""
from typing import List, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.config import settings
from app.resume_parser import _extract_skills


def text_similarity(resume_text: str, job_description: str) -> float:
    """Cosine similarity between resume and JD, as a 0-1 float."""
    if not resume_text.strip() or not job_description.strip():
        return 0.0
    vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
    try:
        tfidf = vectorizer.fit_transform([job_description, resume_text])
    except ValueError:
        # happens if both docs are pure stopwords/empty after filtering
        return 0.0
    sim = cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]
    return float(max(0.0, min(1.0, sim)))


def embedding_similarity(resume_text: str, job_description: str) -> float:
    """
    Placeholder for an LLM/embeddings-based similarity score (bonus
    "semantic search" requirement). Wire this up to an embeddings API and
    swap it in for text_similarity() in compute_match() when available.
    """
    raise NotImplementedError(
        "Plug in an embeddings provider (e.g. sentence-transformers or an "
        "API) here to enable semantic matching."
    )


def skill_overlap(resume_skills: List[str], required: List[str], preferred: List[str]) -> Tuple[float, List[str], List[str]]:
    """
    Returns (score 0-1, matched_skills, missing_skills). Required skills
    count double toward the score versus preferred ones, since missing a
    required skill matters more.
    """
    resume_set = {s.lower() for s in resume_skills}
    required_set = {s.lower() for s in required}
    preferred_set = {s.lower() for s in preferred}

    if not required_set and not preferred_set:
        return 0.0, [], []

    matched = sorted((required_set | preferred_set) & resume_set)
    missing = sorted((required_set | preferred_set) - resume_set)

    req_matched = len(required_set & resume_set)
    pref_matched = len(preferred_set & resume_set)

    weighted_matched = req_matched * 2 + pref_matched * 1
    weighted_total = len(required_set) * 2 + len(preferred_set) * 1
    score = weighted_matched / weighted_total if weighted_total else 0.0

    return score, matched, missing


def compute_match(resume_text: str, resume_skills: List[str], job_description: str,
                   required_skills: List[str], preferred_skills: List[str]) -> dict:
    """
    Combines skill overlap + text similarity into a single 0-100 match
    score, plus the matched/missing skill lists used for shortlisting.
    """
    # If the job didn't specify explicit skill lists, fall back to
    # whatever skills we can detect in the JD text itself.
    if not required_skills and not preferred_skills:
        required_skills = _extract_skills(job_description)

    skill_score, matched, missing = skill_overlap(resume_skills, required_skills, preferred_skills)
    sim_score = text_similarity(resume_text, job_description)

    final_score = (
        skill_score * settings.skill_weight
        + sim_score * settings.text_similarity_weight
    ) * 100

    return {
        "match_score": round(final_score, 1),
        "matched_skills": matched,
        "missing_skills": missing,
        "skill_score": round(skill_score * 100, 1),
        "text_similarity_score": round(sim_score * 100, 1),
    }
