import datetime

from sqlalchemy import (
    Column, Integer, String, Float, Text, DateTime, ForeignKey, JSON
)
from sqlalchemy.orm import relationship

from app.database import Base


class Job(Base):
    """A job posting / job description that resumes get screened against."""
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    required_skills = Column(JSON, default=list)   # e.g. ["python", "sql"]
    preferred_skills = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    candidates = relationship(
        "Candidate", back_populates="job", cascade="all, delete-orphan"
    )


class Candidate(Base):
    """A single parsed resume, scored against one job."""
    __tablename__ = "candidates"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"), nullable=False)

    file_name = Column(String(500))
    raw_text = Column(Text)

    name = Column(String(255))
    email = Column(String(255))
    phone = Column(String(50))
    skills = Column(JSON, default=list)
    education = Column(JSON, default=list)
    experience_years = Column(Float, default=0.0)
    experience_entries = Column(JSON, default=list)
    certifications = Column(JSON, default=list)

    match_score = Column(Float, default=0.0)
    matched_skills = Column(JSON, default=list)
    missing_skills = Column(JSON, default=list)

    shortlisted = Column(Integer, default=0)  # 0/1, kept simple for SQLite
    notified = Column(Integer, default=0)

    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    job = relationship("Job", back_populates="candidates")
