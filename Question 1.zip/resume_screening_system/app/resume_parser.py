"""
Turns a raw resume file (PDF or DOCX) into structured fields: name, email,
phone, skills, education, experience, certifications.

This is intentionally rule-based / regex + keyword driven rather than a
black-box model, because resumes are extremely inconsistent in layout and a
transparent, debuggable extractor is far easier to fix when it misses a
field than a model would be. The skill/keyword lists are the main thing a
team would keep extending over time.
"""
import re
from pathlib import Path
from typing import List, Dict

import pdfplumber
from docx import Document


class ResumeParseError(Exception):
    """Raised when a resume file can't be read or produces no usable text."""


# A reasonably broad seed list of tech/business skills we look for. In
# production this would live in the DB / a config file so it can grow
# without a code change; kept as a constant here for simplicity.
SKILL_KEYWORDS = [
    "python", "java", "c++", "c#", "javascript", "typescript", "go", "rust",
    "sql", "nosql", "postgresql", "mysql", "mongodb", "redis",
    "fastapi", "flask", "django", "spring", "node.js", "express",
    "react", "angular", "vue", "html", "css",
    "machine learning", "deep learning", "nlp", "computer vision",
    "tensorflow", "pytorch", "scikit-learn", "pandas", "numpy",
    "docker", "kubernetes", "aws", "azure", "gcp", "terraform", "ci/cd",
    "git", "linux", "rest api", "graphql", "microservices",
    "data analysis", "data engineering", "etl", "airflow", "spark", "hadoop",
    "excel", "power bi", "tableau",
    "project management", "agile", "scrum", "communication", "leadership",
]

DEGREE_KEYWORDS = [
    "b.tech", "btech", "bachelor", "b.sc", "bsc", "b.e.", "be ",
    "m.tech", "mtech", "master", "m.sc", "msc", "mba", "phd", "ph.d",
    "associate degree", "diploma",
]

EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
PHONE_RE = re.compile(r"(\+?\d{1,3}[-.\s]?)?(\(?\d{2,4}\)?[-.\s]?){2,4}\d{3,4}")
YEARS_EXP_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*\+?\s*years?\s+(?:of\s+)?experience", re.IGNORECASE
)
DATE_RANGE_RE = re.compile(
    r"(\d{4})\s*(?:-|to|–)\s*(\d{4}|present|current)", re.IGNORECASE
)


def extract_text(file_path: str) -> str:
    """Read a .pdf or .docx file and return its plain text content."""
    ext = Path(file_path).suffix.lower()
    try:
        if ext == ".pdf":
            text_parts = []
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text() or ""
                    text_parts.append(page_text)
            text = "\n".join(text_parts)
        elif ext == ".docx":
            doc = Document(file_path)
            text = "\n".join(p.text for p in doc.paragraphs)
            # Tables are common in resumes (skills grids, education tables).
            for table in doc.tables:
                for row in table.rows:
                    text += "\n" + " | ".join(c.text for c in row.cells)
        elif ext == ".txt":
            text = Path(file_path).read_text(errors="ignore")
        else:
            raise ResumeParseError(f"Unsupported file type: {ext}")
    except ResumeParseError:
        raise
    except Exception as exc:
        raise ResumeParseError(f"Failed to read {file_path}: {exc}") from exc

    if not text or not text.strip():
        raise ResumeParseError(f"No extractable text found in {file_path}")
    return text


def _guess_name(text: str) -> str:
    """
    Best-effort name guess: resumes almost always put the candidate's name
    on one of the first couple of non-empty lines, in a short line without
    an @ or digits (which would suggest contact info instead).
    """
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for line in lines[:5]:
        if "@" in line or any(ch.isdigit() for ch in line):
            continue
        words = line.split()
        if 1 <= len(words) <= 4 and all(w[0].isupper() for w in words if w[0].isalpha()):
            return line
    return lines[0] if lines else "Unknown"


def _extract_skills(text: str) -> List[str]:
    lowered = text.lower()
    found = []
    for skill in SKILL_KEYWORDS:
        # word-boundary-ish match so "go" doesn't match inside "going"
        pattern = r"(?<![a-zA-Z0-9])" + re.escape(skill) + r"(?![a-zA-Z0-9])"
        if re.search(pattern, lowered):
            found.append(skill)
    return sorted(set(found))


def _extract_education(text: str) -> List[str]:
    lowered = text.lower()
    hits = []
    for kw in DEGREE_KEYWORDS:
        if kw in lowered:
            # pull the line it appeared on for a bit more context
            for line in text.splitlines():
                if kw in line.lower():
                    hits.append(line.strip())
                    break
    # de-dupe while preserving order
    seen = set()
    out = []
    for h in hits:
        if h not in seen:
            seen.add(h)
            out.append(h)
    return out


def _extract_certifications(text: str) -> List[str]:
    cert_section = re.search(
        r"certifications?\s*[:\n]([\s\S]{0,500}?)(?:\n\s*\n|\Z)",
        text, re.IGNORECASE,
    )
    if not cert_section:
        return []
    block = cert_section.group(1)
    lines = [
        re.sub(r"^[\-\*•\u2022]\s*", "", l.strip())
        for l in block.splitlines() if l.strip()
    ]
    return [l for l in lines if len(l) > 2][:15]


def _extract_experience_years(text: str) -> float:
    m = YEARS_EXP_RE.search(text)
    if m:
        return float(m.group(1))

    # Fall back to summing date ranges found under an "experience" heading.
    total_years = 0.0
    for start, end in DATE_RANGE_RE.findall(text):
        start_year = int(start)
        end_year = 2026 if end.lower() in ("present", "current") else int(end)
        if end_year >= start_year:
            total_years += (end_year - start_year)
    return round(total_years, 1)


def _extract_experience_entries(text: str) -> List[Dict]:
    entries = []
    for match in DATE_RANGE_RE.finditer(text):
        line_start = text.rfind("\n", 0, match.start()) + 1
        line_end = text.find("\n", match.end())
        line_end = line_end if line_end != -1 else len(text)
        entries.append({
            "period": match.group(0),
            "context": text[line_start:line_end].strip()[:150],
        })
    return entries[:10]


def parse_resume(file_path: str) -> Dict:
    """Main entry point: file path -> dict of structured resume fields."""
    text = extract_text(file_path)

    email_match = EMAIL_RE.search(text)
    phone_match = PHONE_RE.search(text)

    return {
        "raw_text": text,
        "name": _guess_name(text),
        "email": email_match.group(0) if email_match else None,
        "phone": phone_match.group(0).strip() if phone_match else None,
        "skills": _extract_skills(text),
        "education": _extract_education(text),
        "certifications": _extract_certifications(text),
        "experience_years": _extract_experience_years(text),
        "experience_entries": _extract_experience_entries(text),
    }
