import io
import smtplib
from email.message import EmailMessage
from typing import List, Optional

import pandas as pd
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app import models, schemas
from app.config import settings
from app.database import get_db
from app.utils.exceptions import CandidateNotFoundError, JobNotFoundError
from app.utils.logger import logger

router = APIRouter(prefix="/candidates", tags=["Candidates"])


def _apply_filters(query, min_experience, education_contains, skill):
    if min_experience is not None:
        query = query.filter(models.Candidate.experience_years >= min_experience)
    if education_contains:
        # naive substring filter across the JSON education list, good enough
        # for a small-to-medium dataset served from SQLite/Postgres.
        query = query.filter(
            models.Candidate.education.cast(str).ilike(f"%{education_contains}%")
        )
    if skill:
        query = query.filter(
            models.Candidate.skills.cast(str).ilike(f"%{skill.lower()}%")
        )
    return query


@router.get("", response_model=List[schemas.CandidateOut])
def list_candidates(
    job_id: int,
    min_experience: Optional[float] = Query(None, description="Minimum years of experience"),
    education_contains: Optional[str] = Query(None, description="Substring match on education, e.g. 'B.Tech'"),
    skill: Optional[str] = Query(None, description="Must have this skill"),
    min_score: Optional[float] = Query(None, description="Minimum match score (0-100)"),
    db: Session = Depends(get_db),
):
    """Ranked candidate list for a job, highest match score first, with optional filters."""
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise JobNotFoundError(job_id)

    query = db.query(models.Candidate).filter(models.Candidate.job_id == job_id)
    query = _apply_filters(query, min_experience, education_contains, skill)
    if min_score is not None:
        query = query.filter(models.Candidate.match_score >= min_score)

    return query.order_by(models.Candidate.match_score.desc()).all()


@router.get("/{candidate_id}", response_model=schemas.CandidateDetail)
def get_candidate(candidate_id: int, db: Session = Depends(get_db)):
    candidate = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not candidate:
        raise CandidateNotFoundError(candidate_id)
    return candidate


@router.get("/export/{job_id}")
def export_candidates(
    job_id: int,
    file_format: str = Query("csv", pattern="^(csv|xlsx)$"),
    db: Session = Depends(get_db),
):
    """Export the ranked shortlist for a job as CSV or Excel."""
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise JobNotFoundError(job_id)

    candidates = (
        db.query(models.Candidate)
        .filter(models.Candidate.job_id == job_id)
        .order_by(models.Candidate.match_score.desc())
        .all()
    )

    rows = [{
        "Rank": i + 1,
        "Name": c.name,
        "Email": c.email,
        "Phone": c.phone,
        "Match Score (%)": c.match_score,
        "Experience (yrs)": c.experience_years,
        "Matched Skills": ", ".join(c.matched_skills or []),
        "Missing Skills": ", ".join(c.missing_skills or []),
        "Education": "; ".join(c.education or []),
        "Certifications": "; ".join(c.certifications or []),
        "Resume File": c.file_name,
        "Shortlisted": "Yes" if c.shortlisted else "No",
    } for i, c in enumerate(candidates)]

    df = pd.DataFrame(rows)
    buffer = io.BytesIO()

    if file_format == "xlsx":
        df.to_excel(buffer, index=False, sheet_name="Candidates")
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        filename = f"job_{job_id}_candidates.xlsx"
    else:
        df.to_csv(buffer, index=False)
        media_type = "text/csv"
        filename = f"job_{job_id}_candidates.csv"

    buffer.seek(0)
    logger.info(f"Exported {len(rows)} candidates for job_id={job_id} as {file_format}")
    return StreamingResponse(
        buffer,
        media_type=media_type,
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.post("/shortlist")
def shortlist_candidates(payload: schemas.ShortlistRequest, db: Session = Depends(get_db)):
    """Mark a set of candidates as shortlisted."""
    updated = (
        db.query(models.Candidate)
        .filter(models.Candidate.id.in_(payload.candidate_ids))
        .all()
    )
    for c in updated:
        c.shortlisted = 1
    db.commit()
    logger.info(f"Shortlisted candidate ids={payload.candidate_ids}")
    return {"shortlisted": [c.id for c in updated]}


@router.post("/notify")
def notify_shortlisted(payload: schemas.ShortlistRequest, db: Session = Depends(get_db)):
    """
    Bonus feature: email shortlisted candidates. Requires SMTP settings in
    the environment; if they're not configured this returns a clear error
    rather than failing silently.
    """
    if not settings.smtp_host:
        return {"detail": "SMTP is not configured; set SMTP_HOST/SMTP_USER/SMTP_PASSWORD to enable notifications."}

    candidates = (
        db.query(models.Candidate)
        .filter(models.Candidate.id.in_(payload.candidate_ids))
        .all()
    )
    sent = []
    with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
        server.starttls()
        server.login(settings.smtp_user, settings.smtp_password)
        for c in candidates:
            if not c.email:
                continue
            msg = EmailMessage()
            msg["Subject"] = "You've been shortlisted!"
            msg["From"] = settings.smtp_from
            msg["To"] = c.email
            msg.set_content(
                f"Hi {c.name or 'there'},\n\n"
                f"Congratulations - you've been shortlisted for the role "
                f"(match score: {c.match_score}%). Our team will be in touch "
                f"about next steps.\n\nBest,\nHiring Team"
            )
            server.send_message(msg)
            c.notified = 1
            sent.append(c.id)
    db.commit()
    logger.info(f"Sent shortlist notifications to candidate ids={sent}")
    return {"notified": sent}


@router.get("/{candidate_id}/interview-questions")
def generate_interview_questions(candidate_id: int, db: Session = Depends(get_db)):
    """
    Bonus feature: generate interview questions tailored to a candidate's
    resume - one per matched skill (to probe depth) and one per missing
    skill (to probe willingness/ability to learn), plus a couple of
    experience-based questions. Template-based so it needs no external API
    key; swap in an LLM call here for more open-ended questions if desired.
    """
    candidate = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not candidate:
        raise CandidateNotFoundError(candidate_id)

    questions = []
    for skill in (candidate.matched_skills or [])[:5]:
        questions.append(f"Can you walk me through a project where you used {skill} to solve a real problem?")
    for skill in (candidate.missing_skills or [])[:3]:
        questions.append(f"Our role involves {skill}, which isn't on your resume - what's your experience with it, if any?")
    if candidate.experience_years:
        questions.append(
            f"You have about {candidate.experience_years} years of experience - "
            f"what's the most challenging project you've worked on in that time?"
        )
    questions.append("Why are you interested in this role, and what would you want to accomplish in the first 90 days?")

    return {"candidate_id": candidate_id, "questions": questions}
