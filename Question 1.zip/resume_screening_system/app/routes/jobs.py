from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import models, schemas
from app.database import get_db
from app.utils.exceptions import JobNotFoundError
from app.utils.logger import logger

router = APIRouter(prefix="/jobs", tags=["Jobs"])


@router.post("", response_model=schemas.JobOut, status_code=201)
def create_job(job_in: schemas.JobCreate, db: Session = Depends(get_db)):
    """Create a new job description that resumes can be screened against."""
    job = models.Job(
        title=job_in.title,
        description=job_in.description,
        required_skills=job_in.required_skills or [],
        preferred_skills=job_in.preferred_skills or [],
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    logger.info(f"Created job '{job.title}' (id={job.id})")
    return job


@router.get("", response_model=List[schemas.JobOut])
def list_jobs(db: Session = Depends(get_db)):
    return db.query(models.Job).order_by(models.Job.created_at.desc()).all()


@router.get("/{job_id}", response_model=schemas.JobOut)
def get_job(job_id: int, db: Session = Depends(get_db)):
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise JobNotFoundError(job_id)
    return job


@router.delete("/{job_id}", status_code=204)
def delete_job(job_id: int, db: Session = Depends(get_db)):
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise JobNotFoundError(job_id)
    db.delete(job)
    db.commit()
    logger.info(f"Deleted job id={job_id}")
