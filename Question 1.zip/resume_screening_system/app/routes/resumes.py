import shutil
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, UploadFile, File, Form
from sqlalchemy.orm import Session

from app import models, schemas
from app.config import settings
from app.database import get_db
from app.matcher import compute_match
from app.resume_parser import parse_resume
from app.utils.exceptions import JobNotFoundError, UnsupportedFileTypeError
from app.utils.logger import logger

router = APIRouter(prefix="/resumes", tags=["Resumes"])

ALLOWED_EXTENSIONS = {".pdf", ".docx"}


@router.post("/upload", response_model=List[schemas.CandidateOut], status_code=201)
async def upload_resumes(
    job_id: int = Form(...),
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
):
    """
    Accepts one or more resume files (PDF/DOCX), parses each one, scores it
    against the given job, stores the result, and returns the ranked
    candidates created from this batch (already sorted, highest score first).
    """
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise JobNotFoundError(job_id)

    upload_dir = Path(settings.upload_dir) / str(job_id)
    upload_dir.mkdir(parents=True, exist_ok=True)

    created_candidates = []

    for upload in files:
        ext = Path(upload.filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise UnsupportedFileTypeError(upload.filename)

        dest_path = upload_dir / upload.filename
        with dest_path.open("wb") as f:
            shutil.copyfileobj(upload.file, f)

        logger.info(f"Parsing resume '{upload.filename}' for job_id={job_id}")
        parsed = parse_resume(str(dest_path))

        match = compute_match(
            resume_text=parsed["raw_text"],
            resume_skills=parsed["skills"],
            job_description=job.description,
            required_skills=job.required_skills or [],
            preferred_skills=job.preferred_skills or [],
        )

        candidate = models.Candidate(
            job_id=job_id,
            file_name=upload.filename,
            raw_text=parsed["raw_text"],
            name=parsed["name"],
            email=parsed["email"],
            phone=parsed["phone"],
            skills=parsed["skills"],
            education=parsed["education"],
            experience_years=parsed["experience_years"],
            experience_entries=parsed["experience_entries"],
            certifications=parsed["certifications"],
            match_score=match["match_score"],
            matched_skills=match["matched_skills"],
            missing_skills=match["missing_skills"],
        )
        db.add(candidate)
        created_candidates.append(candidate)

    db.commit()
    for c in created_candidates:
        db.refresh(c)

    created_candidates.sort(key=lambda c: c.match_score, reverse=True)
    logger.info(f"Processed {len(created_candidates)} resume(s) for job_id={job_id}")
    return created_candidates
