from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, ConfigDict


class JobCreate(BaseModel):
    title: str
    description: str
    required_skills: Optional[List[str]] = None
    preferred_skills: Optional[List[str]] = None


class JobOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: str
    required_skills: List[str]
    preferred_skills: List[str]
    created_at: datetime


class CandidateOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    job_id: int
    file_name: str
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    skills: List[str]
    education: List[str]
    experience_years: float
    certifications: List[str]
    match_score: float
    matched_skills: List[str]
    missing_skills: List[str]
    shortlisted: int
    created_at: datetime


class CandidateDetail(CandidateOut):
    raw_text: str
    experience_entries: List[dict]


class ShortlistRequest(BaseModel):
    candidate_ids: List[int]
