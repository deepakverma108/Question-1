from fastapi import Request, status
from fastapi.responses import JSONResponse

from app.resume_parser import ResumeParseError
from app.utils.logger import logger


class JobNotFoundError(Exception):
    def __init__(self, job_id: int):
        self.job_id = job_id


class CandidateNotFoundError(Exception):
    def __init__(self, candidate_id: int):
        self.candidate_id = candidate_id


class UnsupportedFileTypeError(Exception):
    def __init__(self, filename: str):
        self.filename = filename


def register_exception_handlers(app):
    @app.exception_handler(JobNotFoundError)
    async def job_not_found_handler(request: Request, exc: JobNotFoundError):
        logger.warning(f"Job not found: id={exc.job_id}")
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": f"Job with id {exc.job_id} was not found."},
        )

    @app.exception_handler(CandidateNotFoundError)
    async def candidate_not_found_handler(request: Request, exc: CandidateNotFoundError):
        logger.warning(f"Candidate not found: id={exc.candidate_id}")
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={"detail": f"Candidate with id {exc.candidate_id} was not found."},
        )

    @app.exception_handler(UnsupportedFileTypeError)
    async def unsupported_file_handler(request: Request, exc: UnsupportedFileTypeError):
        logger.warning(f"Rejected unsupported file: {exc.filename}")
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content={"detail": f"Unsupported file type for '{exc.filename}'. Only PDF and DOCX are accepted."},
        )

    @app.exception_handler(ResumeParseError)
    async def resume_parse_error_handler(request: Request, exc: ResumeParseError):
        logger.error(f"Resume parse failure: {exc}")
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": f"Could not parse resume: {exc}"},
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        logger.exception(f"Unhandled error on {request.method} {request.url.path}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An unexpected error occurred. Please try again."},
        )
