import os
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# Point the app at a throwaway SQLite DB before importing it, so tests never
# touch a real Postgres instance or the dev DB file.
os.environ["DATABASE_URL"] = "sqlite:///./test_resume_screening.db"

from app.main import app          # noqa: E402
from app.database import Base, get_db, engine  # noqa: E402

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "..", "sample_data", "resumes")


@pytest.fixture(scope="module", autouse=True)
def setup_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)
    db_file = "./test_resume_screening.db"
    if os.path.exists(db_file):
        os.remove(db_file)


client = TestClient(app)


def test_health_check():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "healthy"


def test_create_and_get_job():
    res = client.post("/api/v1/jobs", json={
        "title": "Backend Python Developer",
        "description": "Need a Python developer with FastAPI and PostgreSQL experience.",
        "required_skills": ["python", "fastapi", "postgresql"],
        "preferred_skills": ["docker", "aws"],
    })
    assert res.status_code == 201
    job = res.json()
    assert job["title"] == "Backend Python Developer"

    res2 = client.get(f"/api/v1/jobs/{job['id']}")
    assert res2.status_code == 200


def test_get_nonexistent_job_returns_404():
    res = client.get("/api/v1/jobs/999999")
    assert res.status_code == 404


def test_upload_resumes_and_rank():
    job_res = client.post("/api/v1/jobs", json={
        "title": "Backend Python Developer",
        "description": "Need a Python developer with FastAPI, PostgreSQL and Docker experience.",
        "required_skills": ["python", "fastapi", "postgresql"],
        "preferred_skills": ["docker", "machine learning"],
    })
    job_id = job_res.json()["id"]

    files = [
        ("files", ("resume_priya_sharma.docx", open(os.path.join(SAMPLE_DIR, "resume_priya_sharma.docx"), "rb"),
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
        ("files", ("resume_arjun_mehta.pdf", open(os.path.join(SAMPLE_DIR, "resume_arjun_mehta.pdf"), "rb"), "application/pdf")),
        ("files", ("resume_sara_khan.docx", open(os.path.join(SAMPLE_DIR, "resume_sara_khan.docx"), "rb"),
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document")),
    ]
    res = client.post("/api/v1/resumes/upload", data={"job_id": job_id}, files=files)
    assert res.status_code == 201
    candidates = res.json()
    assert len(candidates) == 3
    # Should already be sorted highest score first
    scores = [c["match_score"] for c in candidates]
    assert scores == sorted(scores, reverse=True)

    # The senior ML-savvy candidate should outrank the fresh grad on this JD
    names = {c["name"]: c["match_score"] for c in candidates}
    assert names["Sara Khan"] > names["Arjun Mehta"]

    # ---- ranking + filters ----
    list_res = client.get(f"/api/v1/candidates?job_id={job_id}")
    assert list_res.status_code == 200
    assert len(list_res.json()) == 3

    filtered = client.get(f"/api/v1/candidates?job_id={job_id}&min_experience=5")
    assert all(c["experience_years"] >= 5 for c in filtered.json())

    # ---- export ----
    export_res = client.get(f"/api/v1/candidates/export/{job_id}?file_format=csv")
    assert export_res.status_code == 200
    assert export_res.headers["content-type"].startswith("text/csv")

    # ---- shortlist ----
    top_id = candidates[0]["id"]
    shortlist_res = client.post("/api/v1/candidates/shortlist", json={"candidate_ids": [top_id]})
    assert shortlist_res.status_code == 200
    assert top_id in shortlist_res.json()["shortlisted"]

    # ---- interview questions (bonus feature) ----
    q_res = client.get(f"/api/v1/candidates/{top_id}/interview-questions")
    assert q_res.status_code == 200
    assert len(q_res.json()["questions"]) > 0


def test_upload_rejects_unsupported_file_type(tmp_path):
    job_res = client.post("/api/v1/jobs", json={
        "title": "Test Job", "description": "Test description with python skills."
    })
    job_id = job_res.json()["id"]

    bad_file = tmp_path / "resume.exe"
    bad_file.write_text("not a resume")

    with open(bad_file, "rb") as f:
        res = client.post(
            "/api/v1/resumes/upload",
            data={"job_id": job_id},
            files=[("files", ("resume.exe", f, "application/octet-stream"))],
        )
    assert res.status_code == 400


def test_upload_to_nonexistent_job_returns_404():
    res = client.post("/api/v1/resumes/upload", data={"job_id": 999999}, files=[])
    assert res.status_code in (404, 422)
