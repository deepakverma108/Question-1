from app.matcher import compute_match, skill_overlap, text_similarity


def test_skill_overlap_perfect_match():
    score, matched, missing = skill_overlap(
        resume_skills=["python", "sql", "docker"],
        required=["python", "sql"],
        preferred=["docker"],
    )
    assert score == 1.0
    assert missing == []
    assert set(matched) == {"python", "sql", "docker"}


def test_skill_overlap_partial_match_weights_required_higher():
    # Missing a required skill should hurt more than missing a preferred one.
    score_missing_required, _, _ = skill_overlap(
        resume_skills=["docker"],
        required=["python"],
        preferred=["docker"],
    )
    score_missing_preferred, _, _ = skill_overlap(
        resume_skills=["python"],
        required=["python"],
        preferred=["docker"],
    )
    assert score_missing_preferred > score_missing_required


def test_skill_overlap_no_requirements_returns_zero():
    score, matched, missing = skill_overlap([], [], [])
    assert score == 0.0
    assert matched == [] and missing == []


def test_text_similarity_identical_text_is_high():
    text = "Experienced Python developer skilled in FastAPI and PostgreSQL."
    sim = text_similarity(text, text)
    assert sim > 0.99


def test_text_similarity_unrelated_text_is_low():
    resume = "Award-winning pastry chef with a decade of experience in French cuisine."
    jd = "Looking for a Python backend engineer with PostgreSQL and Docker experience."
    sim = text_similarity(resume, jd)
    assert sim < 0.3


def test_compute_match_returns_expected_keys_and_bounds():
    result = compute_match(
        resume_text="Python developer with FastAPI and PostgreSQL experience.",
        resume_skills=["python", "fastapi", "postgresql"],
        job_description="We need a Python developer with FastAPI and PostgreSQL skills.",
        required_skills=["python", "fastapi"],
        preferred_skills=["postgresql"],
    )
    assert set(result.keys()) == {
        "match_score", "matched_skills", "missing_skills",
        "skill_score", "text_similarity_score",
    }
    assert 0 <= result["match_score"] <= 100
    assert result["match_score"] > 70  # strong match should score highly


def test_compute_match_falls_back_to_jd_keywords_when_no_skill_lists():
    result = compute_match(
        resume_text="I have 5 years of Python and Docker experience.",
        resume_skills=["python", "docker"],
        job_description="Looking for a candidate with strong Python and Docker skills.",
        required_skills=[],
        preferred_skills=[],
    )
    assert "python" in result["matched_skills"]
    assert "docker" in result["matched_skills"]
