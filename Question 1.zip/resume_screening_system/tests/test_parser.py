import os
import pytest
from docx import Document

from app.resume_parser import parse_resume, extract_text, ResumeParseError

SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "..", "sample_data", "resumes")


def test_extract_text_from_docx(tmp_path):
    doc = Document()
    doc.add_paragraph("Jane Doe")
    doc.add_paragraph("jane.doe@example.com")
    doc.add_paragraph("Skills: Python, SQL")
    path = tmp_path / "resume.docx"
    doc.save(path)

    text = extract_text(str(path))
    assert "Jane Doe" in text
    assert "jane.doe@example.com" in text


def test_extract_text_unsupported_extension(tmp_path):
    path = tmp_path / "resume.xyz"
    path.write_text("hello")
    with pytest.raises(ResumeParseError):
        extract_text(str(path))


def test_extract_text_empty_file_raises(tmp_path):
    doc = Document()
    path = tmp_path / "empty.docx"
    doc.save(path)
    with pytest.raises(ResumeParseError):
        extract_text(str(path))


def test_parse_resume_sample_docx():
    path = os.path.join(SAMPLE_DIR, "resume_priya_sharma.docx")
    result = parse_resume(path)

    assert result["email"] == "priya.sharma88@gmail.com"
    assert "python" in result["skills"]
    assert "fastapi" in result["skills"]
    assert "postgresql" in result["skills"]
    assert result["experience_years"] > 0
    assert any("B.Tech" in e or "b.tech" in e.lower() for e in result["education"])
    assert len(result["certifications"]) >= 1


def test_parse_resume_sample_pdf():
    path = os.path.join(SAMPLE_DIR, "resume_arjun_mehta.pdf")
    result = parse_resume(path)

    assert result["email"] == "arjun.mehta@example.com"
    assert "java" in result["skills"]
    assert "mysql" in result["skills"]


def test_skill_extraction_avoids_partial_word_matches():
    from app.resume_parser import _extract_skills
    text = "I am going somewhere, not related to Go the language."
    skills = _extract_skills(text)
    # "go" should match here since it appears as a standalone word too
    assert "go" in skills

    text2 = "This is ongoing work, nothing about golang here."
    skills2 = _extract_skills(text2)
    assert "go" not in skills2
