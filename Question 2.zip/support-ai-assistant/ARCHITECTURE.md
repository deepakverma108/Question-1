# Architecture

## Overview

The assistant is a retrieval-augmented generation (RAG) system, but deliberately
avoids a hosted vector-embedding API on the retrieval path: knowledge-base
search runs on TF-IDF + cosine similarity (scikit-learn), which is fast,
free, deterministic, and requires no external calls. Generation is the only
optional network call, and only fires if an `ANTHROPIC_API_KEY` is configured;
otherwise the system falls back to an extractive answer built directly from
the retrieved text.

## Diagram

```mermaid
flowchart TD
    subgraph Client
        A[User / Frontend]
    end

    subgraph API["FastAPI Application"]
        B["/api/v1/documents\n(upload)"]
        C["/api/v1/chat"]
        D["/api/v1/escalations"]
        E["/health"]
    end

    subgraph Ingestion["Ingestion Pipeline"]
        F[Parse PDF / DOCX / TXT]
        G[Clean + Chunk Text]
    end

    subgraph KB["Knowledge Base"]
        H[(TF-IDF Vector Index)]
        I[(Chunk Store)]
    end

    subgraph ChatEngine["Chat Engine"]
        J[Retrieve Top-K Chunks]
        K{Confidence >=\nThreshold?}
        L[Generate Answer\n(Anthropic API or\nextractive fallback)]
        M[Conversation Memory\n(per session_id)]
        N[Escalation Logger]
    end

    A -->|upload doc| B --> F --> G --> H
    G --> I
    A -->|ask question| C --> J
    J --> H
    J --> K
    K -->|yes| L --> M
    K -->|no| N
    L --> M --> C
    N --> C
    A -->|check status| E
    A -->|review escalations| D --> N
```

## Components

| Component | Responsibility | File |
|---|---|---|
| `ingest.py` | Extract text from PDF/DOCX/TXT, clean and chunk it | `app/ingest.py` |
| `retriever.py` | Build/query the TF-IDF index, persist it to disk, log escalations | `app/retriever.py` |
| `chat_engine.py` | Orchestrate retrieval → confidence check → generation, maintain per-session history | `app/chat_engine.py` |
| `main.py` | FastAPI routes, auth, request/response wiring | `app/main.py` |
| `schemas.py` | Pydantic request/response contracts | `app/schemas.py` |
| `config.py` | Environment-driven settings | `app/config.py` |

## Data flow

1. **Ingestion**: a document is uploaded, parsed by file type, cleaned, and
   split into ~800-character overlapping chunks so answers can cite a
   specific, retrievable passage rather than an entire document.
2. **Indexing**: all chunks across all uploaded documents are re-vectorized
   into a single TF-IDF matrix, persisted to `data/index/kb.pkl` so the
   knowledge base survives a restart.
3. **Retrieval**: an incoming question is vectorized with the same
   vectorizer and compared via cosine similarity against every chunk; the
   top-K matches are returned with their scores.
4. **Escalation gate**: if the best match's score is below
   `CONFIDENCE_THRESHOLD`, the assistant returns "I don't know" and writes
   an escalation record (session, message, reason, score, timestamp) to
   `data/escalations.jsonl` instead of guessing.
5. **Generation**: if the gate passes, the retrieved chunks (plus the recent
   conversation history for that `session_id`) are used to produce an
   answer — via the Anthropic API if configured, or an extractive
   fallback otherwise.
6. **Memory**: each session's last N turns are kept in-process (a bounded
   deque keyed by `session_id`) so follow-up questions ("what about for
   annual plans?") resolve correctly.

## Design decisions worth noting in an interview

- **TF-IDF over embeddings for retrieval**: no external dependency, no API
  cost, fully explainable, and strong enough for FAQ/doc-style corpora at
  this scale. Swapping in a hosted embedding model later is a contained
  change (only `retriever.py` would need to change).
- **Escalation is score-based, not just "the model said I don't know"**:
  this catches the case where the knowledge base simply has no relevant
  content, not only the case where the model declines to answer.
- **Generation degrades gracefully**: any API failure (rate limit, network,
  missing key) falls back to an extractive answer rather than a 500 error.
- **In-memory conversation store**: adequate for this assignment's scope;
  for multi-instance production deployment this would move to Redis or a
  database, keyed by `session_id`.
