# Intelligent Customer Support AI Assistant

An AI-powered customer support assistant that answers user questions using a
company's own documentation and FAQs. Built for the "Build an Intelligent
Customer Support AI Assistant" assignment.

- Imports **PDF, DOCX, and TXT** documents into a searchable knowledge base
- Answers questions grounded in that knowledge base (retrieval-augmented)
- Maintains **conversation context** per session
- Gives concise, relevant answers and says **"I don't know"** — with
  automatic **escalation logging** — when it can't find a confident answer

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the system diagram and design
rationale, and [`API_DOCUMENTATION.md`](./API_DOCUMENTATION.md) for the full
API reference.

## How it works, in one paragraph

Uploaded documents are parsed, cleaned, and split into overlapping chunks.
All chunks are indexed with TF-IDF (scikit-learn) so questions can be matched
to the most relevant passages without needing a hosted embedding API. If the
best match's similarity score clears a confidence threshold, the assistant
answers — either using the Anthropic API (if `ANTHROPIC_API_KEY` is set) or,
with no key configured, by extracting the most relevant sentences directly
from the matched passage. If nothing clears the threshold, it answers "I
don't know" and logs an escalation record for a human agent to follow up on.

## Project structure

```
support-ai-assistant/
├── app/
│   ├── main.py          # FastAPI routes
│   ├── config.py         # env-driven settings
│   ├── schemas.py         # request/response models
│   ├── ingest.py           # PDF/DOCX/TXT parsing + chunking
│   ├── retriever.py         # TF-IDF knowledge base + persistence + escalation log
│   └── chat_engine.py        # retrieval -> confidence gate -> generation -> memory
├── data/
│   ├── uploads/            # uploaded source documents
│   └── index/               # persisted TF-IDF index (kb.pkl)
├── tests/
│   └── test_ingest_and_retrieval.py
├── requirements.txt
├── Dockerfile
├── .env.example
├── ARCHITECTURE.md
├── API_DOCUMENTATION.md
└── README.md
```

## Getting started

### 1. Install dependencies

```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment (optional)

```bash
cp .env.example .env
# Fill in ANTHROPIC_API_KEY if you want LLM-generated answers instead of
# the extractive fallback. Everything else has sane defaults.
```

### 3. Run the server

```bash
uvicorn app.main:app --reload
```

Visit `http://127.0.0.1:8000/docs` for interactive Swagger docs.

### 4. Try it out

```bash
# Upload a document
curl -X POST http://127.0.0.1:8000/api/v1/documents \
  -F "file=@/path/to/faq.pdf"

# Ask a question
curl -X POST http://127.0.0.1:8000/api/v1/chat \
  -H "Content-Type: application/json" \
  -d '{"session_id": "demo-1", "message": "What is your refund policy?"}'

# Check what got escalated
curl http://127.0.0.1:8000/api/v1/escalations
```

### 5. Run tests

```bash
pytest tests/ -v
```

## Deployment

A `Dockerfile` is included:

```bash
docker build -t support-ai-assistant .
docker run -p 8000:8000 --env-file .env support-ai-assistant
```

This image runs as-is on Render, Railway, Fly.io, or any container host —
push the repo, point the platform at the `Dockerfile`, set `PORT=8000` (or
let the platform inject `$PORT` and adjust the `CMD` to use it), and add
`ANTHROPIC_API_KEY` as a secret if you want LLM-generated answers.

> **Note:** this repo does not ship with a live deployment link — deploying
> to a hosting provider requires an account/credentials only you have. The
> Dockerfile above is tested to build and run standalone; point it at
> Render/Railway/Fly and the deploy is a few clicks from there.

## Configuration reference

| Variable | Default | Purpose |
|---|---|---|
| `ANTHROPIC_API_KEY` | _(empty)_ | Enables LLM-generated answers; falls back to extractive answers if unset |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-6` | Model used for generation |
| `SUPPORT_API_KEY` | _(empty)_ | If set, required as `X-API-Key` header on `/api/v1/*` routes |
| `TOP_K` | `4` | Chunks retrieved per query |
| `CONFIDENCE_THRESHOLD` | `0.12` | Minimum similarity score before escalating instead of answering |
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | `800` / `120` | Chunking parameters (characters) |
| `MAX_HISTORY_TURNS` | `6` | Conversation turns kept per session |

## Known limitations / next steps

- Conversation memory is in-process (a dict), so it resets on restart and
  doesn't share state across multiple server instances — fine for this
  assignment's scope, would move to Redis for production.
- TF-IDF retrieval works well for FAQ/doc-style content but won't capture
  deep semantic paraphrases the way a hosted embedding model would; that's
  a deliberate scope/cost tradeoff, and `retriever.py` is the only file
  that would need to change to swap it in.
- No document deletion/versioning endpoint yet — documents are additive.
