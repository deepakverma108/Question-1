"""
Conversation handling: keeps per-session history, retrieves relevant chunks,
and generates an answer -- either via the Anthropic API (if ANTHROPIC_API_KEY
is set) or via a deterministic extractive fallback so the assistant is fully
functional offline / without an API key.

Unanswered or low-confidence queries are escalated per the assignment spec.
"""
from collections import defaultdict, deque
from typing import Deque, Dict, List, Tuple

from .config import settings
from .retriever import kb, log_escalation, Chunk

# session_id -> deque of (role, text) turns
_conversations: Dict[str, Deque[Tuple[str, str]]] = defaultdict(
    lambda: deque(maxlen=settings.MAX_HISTORY_TURNS * 2)
)

I_DONT_KNOW = (
    "I don't know based on the information I currently have. "
    "I've flagged this for a member of the support team to follow up."
)


def _format_history(session_id: str) -> str:
    turns = _conversations[session_id]
    lines = [f"{role.upper()}: {text}" for role, text in turns]
    return "\n".join(lines)


def _build_context(chunks: List[Tuple[Chunk, float]]) -> str:
    parts = []
    for chunk, score in chunks:
        parts.append(f"[Source: {chunk.filename} #{chunk.chunk_index} | relevance {score:.2f}]\n{chunk.text}")
    return "\n\n---\n\n".join(parts)


def _extractive_answer(question: str, chunks: List[Tuple[Chunk, float]]) -> str:
    """
    No-LLM fallback: stitches together the most relevant sentences from the
    top chunk(s) so the assistant still produces a usable, grounded answer
    without any external API call.
    """
    if not chunks:
        return I_DONT_KNOW

    best_chunk, _ = chunks[0]
    sentences = [s.strip() for s in best_chunk.text.replace("\n", " ").split(".") if s.strip()]
    snippet = ". ".join(sentences[:3])
    if snippet and not snippet.endswith("."):
        snippet += "."
    return snippet or I_DONT_KNOW


def _llm_answer(question: str, history: str, chunks: List[Tuple[Chunk, float]]) -> str:
    """
    Calls the Anthropic API with the retrieved context. Only used when
    ANTHROPIC_API_KEY is configured; otherwise chat() uses the extractive
    fallback above.
    """
    import anthropic

    client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    context = _build_context(chunks)

    system_prompt = (
        "You are a customer support assistant. Answer the user's question "
        "using ONLY the provided context from company documentation. "
        "Be concise and specific. If the context does not contain the "
        "answer, respond with exactly: \"I don't know.\" Do not make up "
        "information that is not in the context."
    )

    user_content = (
        f"Conversation so far:\n{history}\n\n"
        f"Context from company knowledge base:\n{context}\n\n"
        f"Question: {question}"
    )

    response = client.messages.create(
        model=settings.ANTHROPIC_MODEL,
        max_tokens=500,
        system=system_prompt,
        messages=[{"role": "user", "content": user_content}],
    )
    return "".join(block.text for block in response.content if block.type == "text").strip()


def chat(session_id: str, message: str):
    """
    Returns (answer: str, sources: List[Chunk,float], escalated: bool, confidence: float)
    """
    results = kb.search(message, top_k=settings.TOP_K)
    best_score = results[0][1] if results else 0.0

    escalated = best_score < settings.CONFIDENCE_THRESHOLD

    if escalated:
        log_escalation(
            session_id=session_id,
            message=message,
            reason="low_confidence" if results else "no_matching_content",
            best_score=best_score,
        )
        answer = I_DONT_KNOW
    else:
        history = _format_history(session_id)
        if settings.ANTHROPIC_API_KEY:
            try:
                answer = _llm_answer(message, history, results)
            except Exception:
                # Never let an upstream API hiccup take the assistant down;
                # degrade gracefully to the extractive answer.
                answer = _extractive_answer(message, results)
        else:
            answer = _extractive_answer(message, results)

        if answer.strip().lower().startswith("i don't know"):
            escalated = True
            log_escalation(session_id, message, "model_declined", best_score)

    _conversations[session_id].append(("user", message))
    _conversations[session_id].append(("assistant", answer))

    return answer, results, escalated, best_score
