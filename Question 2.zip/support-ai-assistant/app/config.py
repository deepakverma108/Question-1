"""
Central configuration, driven by environment variables (.env supported via
python-dotenv when present). Keeping this in one place makes the rest of the
app easy to reason about and easy to override in tests / deployment.
"""
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # dotenv is a convenience only -- the app still works with real env vars.
    pass


class Settings:
    # Where uploaded source documents and the persisted index live.
    DATA_DIR: str = os.getenv("DATA_DIR", "data")
    UPLOAD_DIR: str = os.path.join(DATA_DIR, "uploads")
    INDEX_DIR: str = os.path.join(DATA_DIR, "index")
    ESCALATIONS_FILE: str = os.path.join(DATA_DIR, "escalations.jsonl")

    # Chunking
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", "800"))       # characters
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", "120"))  # characters

    # Retrieval
    TOP_K: int = int(os.getenv("TOP_K", "4"))
    CONFIDENCE_THRESHOLD: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.12"))

    # Conversation memory
    MAX_HISTORY_TURNS: int = int(os.getenv("MAX_HISTORY_TURNS", "6"))

    # LLM generation (optional -- falls back to extractive answers if unset)
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    ANTHROPIC_MODEL: str = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")

    # API auth (simple shared-secret header for this assignment's scope)
    API_KEY: str = os.getenv("SUPPORT_API_KEY", "")  # empty = auth disabled


settings = Settings()

os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
os.makedirs(settings.INDEX_DIR, exist_ok=True)
