"""
Document ingestion: extract raw text from PDF / DOCX / TXT, then split it
into overlapping chunks suitable for retrieval.
"""
import os
import re
from typing import List

from .config import settings


class UnsupportedFileType(Exception):
    pass


def extract_text(file_path: str) -> str:
    """Dispatch to the right parser based on file extension."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".txt":
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    if ext == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(file_path)
        pages = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(pages)

    if ext == ".docx":
        import docx
        document = docx.Document(file_path)
        paragraphs = [p.text for p in document.paragraphs]
        # Also pull text out of tables, which FAQs are often formatted as.
        for table in document.tables:
            for row in table.rows:
                paragraphs.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(paragraphs)

    raise UnsupportedFileType(f"Unsupported file type: {ext}")


def clean_text(text: str) -> str:
    text = text.replace("\r\n", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def chunk_text(
    text: str,
    chunk_size: int = settings.CHUNK_SIZE,
    overlap: int = settings.CHUNK_OVERLAP,
) -> List[str]:
    """
    Simple sliding-window chunker over characters, but it snaps chunk
    boundaries to sentence/paragraph breaks where possible so we don't cut
    FAQ entries in half.
    """
    text = clean_text(text)
    if not text:
        return []

    if len(text) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    n = len(text)

    while start < n:
        end = min(start + chunk_size, n)

        if end < n:
            # try to end on a paragraph or sentence boundary near `end`
            window = text[start:end]
            boundary = max(window.rfind("\n\n"), window.rfind(". "))
            if boundary > chunk_size * 0.5:
                end = start + boundary + 1

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        if end >= n:
            break
        start = max(end - overlap, start + 1)

    return chunks


def load_and_chunk(file_path: str) -> List[str]:
    raw = extract_text(file_path)
    return chunk_text(raw)
