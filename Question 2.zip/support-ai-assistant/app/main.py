"""
FastAPI entrypoint for the Intelligent Customer Support AI Assistant.

Run locally:
    uvicorn app.main:app --reload

Then open http://127.0.0.1:8000/docs for interactive API docs (Swagger UI).
"""
import os
import shutil
from typing import List, Optional

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .chat_engine import chat as run_chat
from .ingest import UnsupportedFileType
from .retriever import kb, load_escalations
from .schemas import (
    ChatRequest,
    ChatResponse,
    EscalationRecord,
    HealthResponse,
    SourceSnippet,
    UploadResponse,
)

app = FastAPI(
    title="Intelligent Customer Support AI Assistant",
    description=(
        "Answers user queries from an uploaded knowledge base (PDF/DOCX/TXT), "
        "maintains conversation context, and escalates queries it cannot answer."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}


def require_api_key(x_api_key: Optional[str] = Header(default=None)):
    """Simple shared-secret auth. Disabled entirely if SUPPORT_API_KEY is unset."""
    if settings.API_KEY and x_api_key != settings.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return True


@app.get("/health", response_model=HealthResponse, tags=["System"])
def health():
    stats = kb.stats()
    return HealthResponse(status="ok", **stats)


@app.post(
    "/api/v1/documents",
    response_model=UploadResponse,
    tags=["Knowledge Base"],
    dependencies=[Depends(require_api_key)],
)
async def upload_document(file: UploadFile = File(...)):
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: {sorted(ALLOWED_EXTENSIONS)}",
        )

    dest_path = os.path.join(settings.UPLOAD_DIR, file.filename)
    with open(dest_path, "wb") as out:
        shutil.copyfileobj(file.file, out)

    try:
        doc_id, chunk_count = kb.add_document(dest_path, file.filename)
    except UnsupportedFileType as e:
        raise HTTPException(status_code=400, detail=str(e))

    return UploadResponse(filename=file.filename, chunks_indexed=chunk_count, doc_id=doc_id)


@app.post(
    "/api/v1/chat",
    response_model=ChatResponse,
    tags=["Chat"],
    dependencies=[Depends(require_api_key)],
)
def chat_endpoint(req: ChatRequest):
    answer, results, escalated, confidence = run_chat(req.session_id, req.message)

    sources = [
        SourceSnippet(
            doc_id=chunk.doc_id,
            filename=chunk.filename,
            chunk_index=chunk.chunk_index,
            score=round(score, 4),
            text=chunk.text[:300],
        )
        for chunk, score in results
    ]

    return ChatResponse(
        session_id=req.session_id,
        answer=answer,
        sources=sources,
        escalated=escalated,
        confidence=round(confidence, 4),
    )


@app.get(
    "/api/v1/escalations",
    response_model=List[EscalationRecord],
    tags=["Chat"],
    dependencies=[Depends(require_api_key)],
)
def list_escalations():
    return load_escalations()
