"""
Knowledge base + retriever.

Uses TF-IDF + cosine similarity rather than a hosted embedding API. That
keeps the whole thing dependency-light, deterministic, free to run, and easy
to grade/test locally without any external API key -- while still giving
solid retrieval quality for FAQ / doc-style knowledge bases. The chat layer
(chat_engine.py) is what optionally calls out to an LLM for generation; the
retriever itself never needs network access.
"""
import json
import os
import pickle
import uuid
from dataclasses import dataclass, field
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .config import settings
from .ingest import load_and_chunk


@dataclass
class Chunk:
    doc_id: str
    filename: str
    chunk_index: int
    text: str


@dataclass
class KnowledgeBase:
    chunks: List[Chunk] = field(default_factory=list)
    vectorizer: TfidfVectorizer = None
    matrix = None

    # ---- persistence -----------------------------------------------------

    def _index_path(self) -> str:
        return os.path.join(settings.INDEX_DIR, "kb.pkl")

    def save(self) -> None:
        with open(self._index_path(), "wb") as f:
            pickle.dump({"chunks": self.chunks, "vectorizer": self.vectorizer,
                         "matrix": self.matrix}, f)

    def load(self) -> bool:
        path = self._index_path()
        if not os.path.exists(path):
            return False
        with open(path, "rb") as f:
            state = pickle.load(f)
        self.chunks = state["chunks"]
        self.vectorizer = state["vectorizer"]
        self.matrix = state["matrix"]
        return True

    # ---- ingestion ---------------------------------------------------------

    def add_document(self, file_path: str, filename: str) -> "tuple[str, int]":
        texts = load_and_chunk(file_path)
        doc_id = uuid.uuid4().hex[:12]

        new_chunks = [
            Chunk(doc_id=doc_id, filename=filename, chunk_index=i, text=t)
            for i, t in enumerate(texts)
        ]
        self.chunks.extend(new_chunks)
        self._rebuild_index()
        self.save()
        return doc_id, len(new_chunks)

    def _rebuild_index(self) -> None:
        if not self.chunks:
            self.vectorizer = None
            self.matrix = None
            return
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=50_000,
        )
        corpus = [c.text for c in self.chunks]
        self.matrix = self.vectorizer.fit_transform(corpus)

    # ---- retrieval ---------------------------------------------------------

    def search(self, query: str, top_k: int = settings.TOP_K):
        """Returns a list of (Chunk, score) sorted by descending score."""
        if not self.chunks or self.vectorizer is None:
            return []

        query_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self.matrix).flatten()
        top_indices = sims.argsort()[::-1][:top_k]

        results = [(self.chunks[i], float(sims[i])) for i in top_indices if sims[i] > 0]
        return results

    def stats(self):
        doc_ids = {c.doc_id for c in self.chunks}
        return {"documents_indexed": len(doc_ids), "chunks_indexed": len(self.chunks)}


def log_escalation(session_id: str, message: str, reason: str, best_score: float) -> None:
    import datetime
    record = {
        "session_id": session_id,
        "message": message,
        "reason": reason,
        "best_score": best_score,
        "created_at": datetime.datetime.utcnow().isoformat() + "Z",
    }
    with open(settings.ESCALATIONS_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def load_escalations():
    if not os.path.exists(settings.ESCALATIONS_FILE):
        return []
    with open(settings.ESCALATIONS_FILE, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


# A single process-wide knowledge base instance, loaded lazily.
kb = KnowledgeBase()
kb.load()
