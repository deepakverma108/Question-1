"""
Pydantic models shared across the API.
"""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class UploadResponse(BaseModel):
    filename: str
    chunks_indexed: int
    doc_id: str


class ChatRequest(BaseModel):
    session_id: str = Field(..., description="Client-generated id used to keep conversation context")
    message: str = Field(..., min_length=1)


class SourceSnippet(BaseModel):
    doc_id: str
    filename: str
    chunk_index: int
    score: float
    text: str


class ChatResponse(BaseModel):
    session_id: str
    answer: str
    sources: List[SourceSnippet]
    escalated: bool
    confidence: float


class EscalationRecord(BaseModel):
    session_id: str
    message: str
    reason: str
    created_at: datetime
    best_score: float


class HealthResponse(BaseModel):
    status: str
    documents_indexed: int
    chunks_indexed: int
