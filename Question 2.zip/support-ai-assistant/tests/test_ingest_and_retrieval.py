import os
import sys
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.ingest import chunk_text
from app.retriever import KnowledgeBase


def test_chunk_text_short_returns_single_chunk():
    text = "This is a short FAQ answer."
    chunks = chunk_text(text, chunk_size=800, overlap=120)
    assert chunks == [text]


def test_chunk_text_long_splits_with_overlap():
    text = ("Refunds are processed within 5-7 business days. " * 50)
    chunks = chunk_text(text, chunk_size=200, overlap=40)
    assert len(chunks) > 1
    # every chunk should be non-empty and within a reasonable bound
    assert all(0 < len(c) <= 260 for c in chunks)


def test_knowledge_base_retrieval_returns_relevant_chunk(tmp_path):
    kb = KnowledgeBase()
    kb.INDEX_DIR_OVERRIDE = str(tmp_path)  # not used by save(), kept simple for this test

    faq_path = tmp_path / "faq.txt"
    faq_path.write_text(
        "How do I reset my password?\n"
        "Go to Settings > Security > Reset Password and follow the emailed link.\n\n"
        "What are your support hours?\n"
        "Our support team is available 9am-6pm EST, Monday through Friday."
    )

    kb.add_document(str(faq_path), "faq.txt")
    results = kb.search("How can I change my password?", top_k=2)

    assert len(results) > 0
    top_chunk, score = results[0]
    assert "password" in top_chunk.text.lower()
    assert score > 0


def test_knowledge_base_empty_returns_no_results():
    kb = KnowledgeBase()
    assert kb.search("anything") == []
